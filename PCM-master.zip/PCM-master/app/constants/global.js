module.exports = {
    accessToken: '',
    channelId: 'PCM-Channel',
    channelName: 'PCM-Channel',
    channelDesc: 'A channel for PCM notifications',
    navigation: null,
};