<template>
  <div class="homeTemplate">
    <div class="homeTemplateTitle"><h1>Create a Post! test</h1></div>
    <div class="appForm">
      <form @submit.prevent="createPost" class="form">
        <label class="label">Title</label>
        <input type="text" v-model="title">
        <label class="label">Body</label>
        <textarea v-model="body"></textarea>
        <label class="label">Select image</label>
        <input ref="fileInput" type="file" @input="pickFile">
        <button type="submit" class="btn">Post</button>
      </form>
        <div class="readPosts">
          <div class="postTitle"><h1>Read Posts</h1></div>
          <div class="testPost2"> 
            <h1>How to add friends</h1>
            <b>Looking to add friends to your Groupomania network? We can help you get started! Just head to your ...</b>
          </div>
          <div class="learnMore" href="https://www.google.com/" ><b>click here to learn more</b></div> 
          <div class="readPost"></div>
        </div>
            <div class="loginForm">
              <form>
                <h1> Sign in </h1>
                <div class="login_layout">
                  <input class="field" type="email" placeholder="Email" />
                  <input class="field" type="password" placeholder="Password" />
                  <button class="field btn">Sign in</button>
                </div>
              </form>
            </div>
    </div>
    <div class="unreadPosts">
      <div class="unreadTitle"><h1>Unread Posts</h1></div>
      <div class="testPost"> 
        <h1>Welcome post!</h1>
        <b>Welcome to our page! We are so glad you decided to join our Groupomania network.</b> 
      </div>
      <div class="post">
          <div v-for="(post, index) in posts" :key="index">
            <Post :title="post.title" :body="post.body"></Post>
            <div class="imagePreviewWrapper"
              :style="{ 'background-image': `url(${previewImage})` }" @click="selectImage">
            </div>
            <button type="submit" class="btn">Update</button>
            <button type="submit" class="btn">Delete</button>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import Post from '../components/Post.vue';

export default {
  name: 'App',
  components:{
    Post, 
  },
  
  data: () => ({
    title: '',
    body: '',
    image: '',
    posts: [
    ]
  }),
  methods: {
    selectImage () {
      this.$refs.fileInput.click()
    },
    pickFile () {
      let input = this.$refs.fileInput
      let file = input.files
      if (file && file[0]) {
        let reader = new FileReader
        reader.onload = e => {
          this.previewImage = e.target.result
        }
        reader.readAsDataURL(file[0])
        this.$emit('input', file[0])
      }
    },
    createPost () {
      this.posts.unshift({
        title: this.title,
        body: this.body,
        image: this.image,
      })
      this.title = ''
      this.body = ''
      this.image = ''
    }
  }
  
}
</script>

<style>
.appForm {
  display: flex;
  justify-content: space-around;
  height: 300px;
}
.form {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 30%;
  border: black 1px solid;
  border-radius: 10px 10px;
}
.label{
  margin-top: 20px;
  font-size: 20px;
  color: blue;
}
.btn{
  margin-top: 20px;
  font-size: 15px;
}
.imagePreviewWrapper {
    width: 200px;
    height: 170px;
    display: block;
    cursor: pointer;
    margin: 0 auto 10px;
    background-size: cover;
    background-position: center center;
}
header {
  display: flex;
  top: 0px;
  width: 100%;
  z-index: var(--z-fixed);
}
.post {
  border: black 1px solid;
  box-shadow: 10px black;
  padding: 10px;
  width: 30%;
  border-radius: 10px;
  margin-left: 9px;
  
}
.postTitle, .unreadTitle, .testPost, .testPost2 {
  border: black 1px solid;
  border-radius: 10px;
  margin: 10px;
  padding: 2px;
}
.unreadTitle {
  width: 16.1%;
}
.testPost {
  display: flex;
  flex-flow: wrap;
  justify-content: center;
  padding: 10px;
  width: 350px;
}
.readPosts {
  border: black 1px solid;
  border-radius: 10px;
  width: 350px;
  height: 250px;
  margin: auto;
}
.learnMore {
  display: flex;
  justify-content: center;
}
.readPost {
  display: flex;
  align-content: flex-start;
}
.homeTemplateTitle{
  display: flex;
  justify-content: center;
  border: black 1px solid;
  border-radius: 10px;
  width: 17%;
  margin-bottom: 10px;
  margin-left: 10px;
  
}
.loginForm{
  border: black 1px solid;
  border-radius: 10px;
  padding: 10px;
  width: 33%;
  margin: auto;
}
.field {
  padding: 10px;
}
.login_layout {
  width: 375px;
}
</style>
