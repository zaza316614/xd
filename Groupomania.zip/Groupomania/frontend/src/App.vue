<script setup>
import { RouterLink, RouterView } from "vue-router";
</script>

<template>
  <div class="app">
    <header>
      <div class="image"><img
        alt="Vue logo"
        class="logo"
        src="@/assets/logo.svg"
        width="75"
        height="75"
      /></div>
      <div class="wrapper">
        <nav>
          <div class="routerLink"><RouterLink to="/">Home</RouterLink></div>
          <div class="routerLink"><RouterLink to="/login-signup">Login or Signup</RouterLink></div>
        </nav>
      </div>
    </header>
  <RouterView></RouterView>
  </div>
</template>

<style scoped>
.image {
  margin: 10px 0px 0px 20px;
}

header {
  line-height: 1.5;
  max-height: 30vh;
  width: 100%;
  display: flex;
  justify-content: space-between;
  margin: 10px 10px 0px 0px;
}

.logo {
  display: block;
  margin: 0px 170px 0px 0px;
}

nav {
  font-size: 12px;
  text-align: center;
  display: flex;
  margin-top: 2rem;
}

.routerLink {
  border: black 1px solid;
  border-radius: 10px;
  margin: 10px;
}
.app {
  transition: box-shadow 0.5s ease-in-out;
  border-radius: 10px;
  box-shadow: 5px 5px 5px 5px  black;
}

nav a.router-link-exact-active {
  color: black;

}

nav a.router-link-exact-active:hover {
  background-color: transparent;
}

nav a {
  display: inline-block;
  padding: 0 1rem;
  border-left: 1px solid var(--color-border);
  color: black;
}

nav a:first-of-type {
  border: 0;
}

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
    flex-wrap: wrap;
  }

  nav {
    text-align: left;
    margin-left: -1rem;
    font-size: 1rem;
    padding: 1rem 0;
    margin-top: 1rem;
  }
}
</style>
